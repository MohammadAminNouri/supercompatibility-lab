#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="/workspaces/supercompatibility-lab"
APP="$ROOT/supercompatibility_final.py"
[[ -f "$APP" ]] || { echo "ERROR: expected $APP"; exit 1; }

echo "=== VERIFYING CANDIDATE BEFORE TOUCHING YOUR APP ==="
(cd "$HERE/candidate" && python verify_final_academic_v4.py)

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$ROOT/.safe_backups/pre-final-academic-v4-$STAMP"
mkdir -p "$BACKUP_DIR"
cp "$APP" "$BACKUP_DIR/supercompatibility_final.py"
printf '%s
' "$BACKUP_DIR/supercompatibility_final.py" > "$ROOT/.last_pre_v4_backup"

restore_on_error() {
  echo
  echo "A validation step failed. Restoring the previous app automatically."
  cp "$BACKUP_DIR/supercompatibility_final.py" "$APP"
}
trap restore_on_error ERR

cp "$HERE/candidate/supercompatibility_final.py" "$APP"
cp "$HERE/candidate/verify_final_academic_v4.py" "$ROOT/verify_final_academic_v4.py"
cd "$ROOT"

echo "=== VERIFYING INSTALLED APP ==="
python verify_final_academic_v4.py

# Run the repository's own scientific/release checks when present.
for script in   scripts/deployment_preflight.py   scripts/verify_embedded_app.py   scripts/verify_equation_parity.py   scripts/verify_release.py   research_selftest.py; do
  if [[ -f "$script" ]]; then
    echo "=== RUNNING $script ==="
    python "$script"
  fi
done
if [[ -d tests ]]; then
  echo "=== RUNNING REPOSITORY TEST SUITE ==="
  python -m pytest -q
fi
trap - ERR

echo
echo "INSTALLATION + AVAILABLE SCIENTIFIC CHECKS PASSED"
echo "Previous app backup: $BACKUP_DIR/supercompatibility_final.py"
echo "Run: python -m streamlit run supercompatibility_final.py"
