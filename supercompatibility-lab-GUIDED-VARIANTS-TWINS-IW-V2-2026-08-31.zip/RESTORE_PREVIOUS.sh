#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f .last_supercompat_backup_path ]]; then
  echo "No recorded backup path found."
  exit 1
fi
BACKUP="$(cat .last_supercompat_backup_path)"
if [[ ! -f "$BACKUP" ]]; then
  echo "Recorded backup does not exist: $BACKUP"
  exit 1
fi
cp -a "$BACKUP" supercompatibility_final.py
echo "RESTORED: $BACKUP -> supercompatibility_final.py"
