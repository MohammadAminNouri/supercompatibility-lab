# Final release manifest

**Build ID:** `2026-08-31-final-b19-cycle-reconstruction`

**Recommended Streamlit entrypoint:** `supercompatibility_final.py`

## Scientific release checks completed before packaging

- 89/89 collected automated tests passed in the final validated batches (24 + 9 + 21 + 9 + 9 + 4 + 4 + 9).
- Equation/source parity audit passed.
- Deployment preflight passed.
- Embedded-engine scientific self-test passed.
- Numerical release audit passed.
- Deterministic embedded-bundle audit passed: all 27 `src` Python modules and all 9 data assets match the self-contained Streamlit bundle byte-for-byte.
- `app.py`, `streamlit_app.py`, `supercompatibility_r7.py`, and `supercompatibility_final.py` are byte-identical deployment aliases.
- Obsolete upgrade/bootstrap backups and stale R6 deployment instructions were removed from the GitHub-ready release root.
- Parent/daughter reconstruction validation recovered the deterministic two-parent benchmark with all five implemented methods.
- Reconstruction-specific tests cover robust ANG/CTF parsing, explicit phase/reference-frame guards, raw-point segmentation, candidate ambiguity, ARI/NMI/boundary/orientation agreement, operator statistics and the academic evidence ZIP.
- New cycle tests cover the metric-aware NiTi B2↔B19′ natural/AQ OR, 12 regenerated B19′ branches, daughter→parent→daughter closure, branch occupancy, branch-switch geometry, independent later-cycle daughter matching and the cycle evidence ZIP.
- The cycle workflow explicitly distinguishes **internal round-trip consistency** from **independent later-cycle EBSD validation** and never turns an allowed daughter orientation into a claimed nucleation probability.
- The source-discrepancy register is preserved in `docs/SOURCE_DISCREPANCIES.md`; discrepancies are surfaced rather than silently reconciled.
- Formula notation, operators, primary inputs, and core outputs are covered by the explicit notation/provenance layer and tested in `tests/test_symbol_completeness.py`.

## GitHub Actions

The files `.github/workflows/ci.yml` and `.github/workflows/tests.yml` trigger automatically on pushes and pull requests. The main CI installs the pinned dependencies and performs a real Streamlit health check.

## Streamlit Community Cloud

Use:

- Branch: `main`
- Main file path: `supercompatibility_final.py`
- Python: `3.12`

The visible build identifier must be `2026-08-31-final-b19-cycle-reconstruction`.

## Environment note

The packaging container used for this release does not provide the Streamlit browser runtime. GitHub Actions installs the pinned Streamlit dependency and requires the `/_stcore/health` endpoint to pass before CI is green.
