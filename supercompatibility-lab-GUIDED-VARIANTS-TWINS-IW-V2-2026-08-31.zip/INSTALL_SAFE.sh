#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f supercompatibility_final.py ]]; then
  echo "ERROR: run this from /workspaces/supercompatibility-lab"
  exit 1
fi
if [[ ! -f candidate/supercompatibility_final.py ]]; then
  echo "ERROR: candidate/supercompatibility_final.py not found. Unzip the package first."
  exit 1
fi

echo "Pre-install scientific verification of candidate..."
( cd candidate && python verify_guided_upgrade.py )

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP=".safe_backups/pre-guided-workspace3-${STAMP}"
mkdir -p "$BACKUP"
cp -a supercompatibility_final.py "$BACKUP/supercompatibility_final.py"
printf '%s\n' "$BACKUP/supercompatibility_final.py" > .last_supercompat_backup_path

echo "Backup created: $BACKUP/supercompatibility_final.py"

cp candidate/supercompatibility_final.py ./supercompatibility_final.py
cp candidate/verify_guided_upgrade.py ./verify_guided_upgrade.py
python verify_guided_upgrade.py

echo
echo "INSTALLED: guided Workspace 3 revision"
echo "To restore immediately: bash RESTORE_PREVIOUS.sh"
