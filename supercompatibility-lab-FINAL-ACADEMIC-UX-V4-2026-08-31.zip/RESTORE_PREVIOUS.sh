#!/usr/bin/env bash
set -euo pipefail
ROOT="/workspaces/supercompatibility-lab"
cd "$ROOT"
if [[ ! -f .last_pre_v4_backup ]]; then echo "No V4 backup pointer found."; exit 1; fi
BACKUP="$(cat .last_pre_v4_backup)"
[[ -f "$BACKUP" ]] || { echo "Backup not found: $BACKUP"; exit 1; }
cp "$BACKUP" supercompatibility_final.py
echo "Restored: $BACKUP"
