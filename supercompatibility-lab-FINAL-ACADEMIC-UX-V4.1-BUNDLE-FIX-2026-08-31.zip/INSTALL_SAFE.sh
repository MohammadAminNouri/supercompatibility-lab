#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="/workspaces/supercompatibility-lab"
CANDIDATE="$HERE/candidate/supercompatibility_final.py"

ENTRYPOINTS=(
  "app.py"
  "streamlit_app.py"
  "supercompatibility_r7.py"
  "supercompatibility_final.py"
)

cd "$ROOT"

echo "=== V4.1 DETERMINISTIC-BUNDLE INSTALL ==="
echo "Repository: $ROOT"

for f in "${ENTRYPOINTS[@]}"; do
  [[ -f "$f" ]] || {
    echo "ERROR: required deterministic Streamlit entrypoint is missing: $f"
    echo "Nothing was changed."
    exit 1
  }
done

echo
echo "=== VERIFYING CANDIDATE BEFORE TOUCHING REPOSITORY ==="
(cd "$HERE/candidate" && python verify_final_academic_v4.py)

CANDIDATE_SHA="$(sha256sum "$CANDIDATE" | awk '{print $1}')"
echo "Candidate SHA256: $CANDIDATE_SHA"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$ROOT/.safe_backups/pre-final-academic-v4-1-$STAMP"
mkdir -p "$BACKUP_DIR"

echo
echo "=== BACKING UP ALL FOUR ENTRYPOINTS ==="
for f in "${ENTRYPOINTS[@]}"; do
  cp -p "$f" "$BACKUP_DIR/$f"
  echo "BACKUP: $f"
done
printf '%s\n' "$BACKUP_DIR" > "$ROOT/.last_pre_v4_1_backup"

restore_all() {
  echo
  echo "A validation step failed."
  echo "Restoring ALL FOUR previous deterministic entrypoints automatically..."
  for f in "${ENTRYPOINTS[@]}"; do
    if [[ -f "$BACKUP_DIR/$f" ]]; then
      cp -p "$BACKUP_DIR/$f" "$ROOT/$f"
      echo "RESTORED: $f"
    fi
  done
}
trap restore_all ERR

echo
echo "=== INSTALLING IDENTICAL VERIFIED APP INTO ALL FOUR ENTRYPOINTS ==="
for f in "${ENTRYPOINTS[@]}"; do
  cp "$CANDIDATE" "$ROOT/$f"
  echo "INSTALLED: $f"
done

cp "$HERE/candidate/verify_final_academic_v4.py" "$ROOT/verify_final_academic_v4.py"

echo
echo "=== BYTE-IDENTITY CHECK ==="
declare -A HASHES
for f in "${ENTRYPOINTS[@]}"; do
  H="$(sha256sum "$f" | awk '{print $1}')"
  HASHES["$f"]="$H"
  printf '%-30s %s\n' "$f" "$H"
  [[ "$H" == "$CANDIDATE_SHA" ]] || {
    echo "FAIL: $f does not match candidate."
    false
  }
done
echo "PASS: all four deterministic entrypoints are byte-identical."

echo
echo "=== VERIFYING INSTALLED SCIENTIFIC / UX BUILD ==="
python verify_final_academic_v4.py

for script in \
  scripts/deployment_preflight.py \
  scripts/verify_embedded_app.py \
  scripts/verify_equation_parity.py \
  scripts/verify_release.py \
  research_selftest.py
do
  if [[ -f "$script" ]]; then
    echo
    echo "=== RUNNING $script ==="
    python "$script"
  fi
done

if [[ -d tests ]]; then
  echo
  echo "=== RUNNING REPOSITORY TEST SUITE ==="
  python -m pytest -q
fi

trap - ERR

echo
echo "============================================================"
echo "FINAL ACADEMIC V4.1 INSTALLATION PASSED"
echo "============================================================"
echo "All four Streamlit entrypoints are byte-identical."
echo "Backup directory:"
echo "  $BACKUP_DIR"
echo
echo "Launch:"
echo "  python -m streamlit run supercompatibility_final.py"
