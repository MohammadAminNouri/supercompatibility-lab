#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f .last_paper_ready_v3_backup ]]; then
  echo "No V3 backup pointer found."; exit 1
fi
B="$(cat .last_paper_ready_v3_backup)"
if [[ ! -f "$B/supercompatibility_final.py" ]]; then
  echo "Backup file missing: $B/supercompatibility_final.py"; exit 1
fi
cp -a "$B/supercompatibility_final.py" ./supercompatibility_final.py
echo "Restored: $B/supercompatibility_final.py"
