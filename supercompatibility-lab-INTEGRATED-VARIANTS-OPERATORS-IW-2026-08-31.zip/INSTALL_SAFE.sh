#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f supercompatibility_final.py ]]; then
  echo "ERROR: run from /workspaces/supercompatibility-lab"
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p ".safe_backups/$STAMP"
cp supercompatibility_final.py ".safe_backups/$STAMP/supercompatibility_final.py"

echo "Backup: .safe_backups/$STAMP/supercompatibility_final.py"
cp integrated/supercompatibility_final.py ./supercompatibility_final.py
cp integrated/verify_integrated_upgrade.py ./verify_integrated_upgrade.py

python verify_integrated_upgrade.py

echo
echo "Upgrade installed. Your previous app is preserved in .safe_backups/$STAMP/"
