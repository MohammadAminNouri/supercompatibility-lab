#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f supercompatibility_final.py ]]; then
  echo "ERROR: run from /workspaces/supercompatibility-lab"
  exit 1
fi

echo "=== VERIFYING CANDIDATE BEFORE TOUCHING CURRENT APP ==="
(cd paper_ready_v3 && python verify_paper_ready_v3.py)

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR=".safe_backups/pre-paper-ready-v3-${STAMP}"
mkdir -p "$BACKUP_DIR"
cp -a supercompatibility_final.py "$BACKUP_DIR/supercompatibility_final.py"

echo "Backup created: $BACKUP_DIR/supercompatibility_final.py"
cp -a paper_ready_v3/supercompatibility_final.py ./supercompatibility_final.py
cp -a paper_ready_v3/verify_paper_ready_v3.py ./verify_paper_ready_v3.py

echo
echo "=== VERIFYING INSTALLED APP ==="
python verify_paper_ready_v3.py

echo "$BACKUP_DIR" > .last_paper_ready_v3_backup
echo
echo "PAPER-READY V3 INSTALLED SUCCESSFULLY"
echo "Restore path saved in .last_paper_ready_v3_backup"
