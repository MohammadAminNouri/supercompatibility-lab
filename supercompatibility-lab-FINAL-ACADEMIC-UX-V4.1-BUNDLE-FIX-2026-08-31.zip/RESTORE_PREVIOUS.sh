#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspaces/supercompatibility-lab"
cd "$ROOT"

ENTRYPOINTS=(
  "app.py"
  "streamlit_app.py"
  "supercompatibility_r7.py"
  "supercompatibility_final.py"
)

[[ -f .last_pre_v4_1_backup ]] || {
  echo "No V4.1 backup pointer found."
  exit 1
}

BACKUP_DIR="$(cat .last_pre_v4_1_backup)"
[[ -d "$BACKUP_DIR" ]] || {
  echo "Backup directory not found: $BACKUP_DIR"
  exit 1
}

for f in "${ENTRYPOINTS[@]}"; do
  [[ -f "$BACKUP_DIR/$f" ]] || {
    echo "Backup missing: $BACKUP_DIR/$f"
    exit 1
  }
done

for f in "${ENTRYPOINTS[@]}"; do
  cp -p "$BACKUP_DIR/$f" "$ROOT/$f"
  echo "RESTORED: $f"
done

echo "Restored all four deterministic entrypoints from:"
echo "$BACKUP_DIR"
